title: IBInspectable无法取值的问题
date: '2018-11-09 22:40:54'
updated: '2018-11-09 22:40:54'
tags: [GCD, iOS]
permalink: /articles/2018/11/09/1573699411284.html
---
我在xib文件里用了IBInspectable然后在UIView的layoutSubviews里执行

    dispatch_async(dispatch_get_main_queue(), ^{ //some code}

竟然取不到相应IBInspectable标记的值，如果在block的外边重新声明新的变量并赋值才可以
如图：

![Paste_Image.png](http://upload-images.jianshu.io/upload_images/69809-192d31537be63fe1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

奇怪的问题，特此记录