title: UIImagePickerController不走回调的问题
date: '2018-11-09 22:34:45'
updated: '2018-11-09 22:34:45'
tags: [exception, iOS, imagePicker]
permalink: /articles/2018/11/09/1573699413753.html
---
#### 今天又遇到了一个奇怪的问题
代码如下：

```
UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
imagePicker.allowsEditing = YES;
imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
imagePicker.delegate = self;
[self presentViewController:imagePicker animated:YES completion:nil];
```
用法很对，没毛病，可就是不调用
```
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
```
#### 分析原因

+  UIImagePickerController实例对象被释放了 //这不可能，如果iOS系统没疯那肯定是我疯了
+ UIImagePickerControllerd的delegate被释放了 //但是delegate是当前视图控制器肯定也没有释放
+ delegate被改了 //看了看代码没有改动的地方啊

???
诡异的事件
。。。

后来我用kvo监测了一下delegate，发现果然被改了，改成了 `_JZNavigationDelegating` ...

#### 真相大白
原来是我在pod里加入了一个帮助处理NavigationBar颜色的第三方库，这个库对UINavigationController做了一些处理，如下图
![image.png](http://upload-images.jianshu.io/upload_images/69809-032f067659e35474.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

而我们今天的主角 *UIImagePickerController*恰恰就是UINavigationController的子类