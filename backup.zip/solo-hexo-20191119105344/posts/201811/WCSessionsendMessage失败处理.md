title: WCSession-sendMessage-失败处理
date: '2018-11-09 22:35:43'
updated: '2018-11-09 22:35:43'
tags: [exception, iOS, watch]
permalink: /articles/2018/11/09/1573699415565.html
---
通过手表向手机端发送消息时出现Payload could not be delivered(中文环境下:未能传送负载)的错误提示,如果你保证你的设置都对的情况下,请记得检查手机端WCSession实现的代理方法全不全

如果你是这样发送消息

    session.sendMessage(["request" : "list"], replyHandler: nil, errorHandler: { (error) in print(error)})

那么在手机端你要有这样的代理方法

    public func session(_ session: WCSession, didReceiveMessage message: [String : Any])

如果你是这样发送消息

    session.sendMessage(["request" : "list"], replyHandler: { (result) in
                        print(result)
                    }, errorHandler: { (error) in print(error) })

那么在手机端你要有这样的代理方法

    public func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Swift.Void)
    
根据发送时有没有replyHandler来决定调用哪个代理方法,如果不匹配就会发送失败