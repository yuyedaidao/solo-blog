title: 为什么dispatch_sync在主线程会死锁
date: '2018-11-09 22:24:12'
updated: '2018-11-09 22:24:12'
tags: [GCD, iOS]
permalink: /articles/2018/11/09/1573699411984.html
---
首先看下面一段代码
    
    dispatch_queue_t queue = dispatch_queue_create("abc", DISPATCH_QUEUE_SERIAL);
    dispatch_sync(queue, ^{//taskA
        //do something
        dispatch_sync(queue, ^{//taskB
        //啥也干不了
        });
    });
    
dispatch_sync函数用于将一个block(任务)提交到队列中同步执行，直到block执行完后，这个函数才会返回。queue是一个串行队列，如果先后加入两个任务，taskA和taskB, 那么只有taskA执行完之后taskB才能执行。如果taskB是在taskA中加进队列的，那么它们依然遵守先进先出原则，即taskA执行完之后taskB才执行，也就是taskB在等待taskA完成。但是因为dispatch_sync的同步特性,taskB执行不完taskA就不算完成，即taskA在等待taskB的完成，这样就发生了死锁。

根据上面那份代码，我们就可以理解下面的代码为什么会阻塞主线程了。

    dispatch_queue_t mainQueue = dispatch_get_main_queue();
    dispatch_sync(mainQueue, ^{
        NSLog(@"hello");
    });

mainQueue是系统创建的，在执行上面的代码之前就已经加进去了很多任务

    dispatch_queue_t queue = dispatch_queue_create("Main", DISPATCH_QUEUE_SERIAL);
    dispatch_sync(queue, ^{
    //Task A
    });
    ...
    dispatch_sync(queue, ^{
    //Task N
    });
 
在这N个任务里有一个任务是这样的：

    dispatch_sync(queue, ^{
        dispatch_queue_t mainQueue = dispatch_get_main_queue();
        dispatch_sync(mainQueue, ^{
            NSLog(@"hello");
        });
    });

所以，发生死锁就是必然的了。