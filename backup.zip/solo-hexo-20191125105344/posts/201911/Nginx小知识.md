title: Nginx小知识
date: '2019-11-14 14:55:13'
updated: '2019-11-14 14:55:13'
tags: [nginx]
permalink: /articles/2019/11/14/1573714513221.html
---
### `root`和`alias`
```
location /images {
	root /data/
}
```
访问此规则时会去你服务器的`/data/images`路径下查找资源
```
location /images {
	alias /data/
}
```
 访问此规则会去你服务器的`/data/`路径下查找资源
**总结：**`root`拼接 `alias`替换

### 匹配优先级
1. =
1. ^~
1. ~
1. /

由上向下优先级递减
