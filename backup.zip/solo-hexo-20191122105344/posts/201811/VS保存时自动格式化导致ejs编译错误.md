title: VS保存时自动格式化导致ejs编译错误
date: '2018-11-09 22:35:13'
updated: '2018-11-09 22:35:13'
tags: [ejs, exception, vs]
permalink: /articles/2018/11/09/1573699413262.html
---
ejs模板引擎不知道大家有没有好的格式化插件,有的话,求一个
最近遇到一个ejs解析的问题,非常小心的写好ejs文件,一运行出了错,如下
```
Invalid or unexpected token in /Users/wang/Desktop/Work/Node/nobook/views/web-index.ejs while compiling ejs If the above error is not helpful, you may want to try EJS-Lint: https://github.com/RyanZim/EJS-Lint

SyntaxError: Invalid or unexpected token in /Users/wang/Desktop/Work/Node/nobook/views/web-index.ejs while compiling ejs

If the above error is not helpful, you may want to try EJS-Lint:
https://github.com/RyanZim/EJS-Lint
    at new Function (<anonymous>)
...
```
完全看不到有用的信息,shit

于是我就按提示用 https://github.com/RyanZim/EJS-Lint 来试试能不能看到更多信息...
心累啊,用命令号执行直接返回了没有任何信息.加在工程里返回undefined, MMP.姿势不对?有掌握动作要领的请指教.

在折磨了接近两天的时间后我不得对我接近千行的ejs文件一行行ejs代码进行查看,还是没错啊...要你你能不崩溃?

最最后,我就重新把带有ejs代码的片段一段段摘出来,然后一遍遍部署运行,终于...苍天啊.

```
<a href="javascript:void(0)" onclick=<%- '\'deleteAlert( "'+ item.name + '", "' + item._id + '") \ '' %>
```
如上这就是问题代码,估计再细心你可能也没法很多发现问题吧...
其实我的原始代码是
```
<a href="javascript:void(0)" onclick=<%- '\'deleteAlert( "'+ item.name + '", "' + item._id + '") \'' %>
```
发现了,他妈的最后一个转义斜杠`\`后边接了个空格...wtf.
而这都是我在保存时vs给我自动格式化造成的.

说了太多脏话.反思