title: CADisplayLink不销毁导致其拥有者也不释放
date: '2018-11-09 22:25:29'
updated: '2018-11-09 22:25:29'
tags: [CADisplayLink, exception, iOS]
permalink: /articles/2018/11/09/1573699410626.html
---
我发现我在拥有CADisplayLink且其没有invilidate的情况下，会让其所有者没法销毁