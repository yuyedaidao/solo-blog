title: 我在 GitHub 上的开源项目
date: '2019-11-15 10:43:42'
updated: '2019-11-15 10:43:42'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [pili-ios-camera-recorder](https://github.com/yuyedaidao/pili-ios-camera-recorder) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`11`](https://github.com/yuyedaidao/pili-ios-camera-recorder/watchers "关注数")&nbsp;&nbsp;[⭐️`58`](https://github.com/yuyedaidao/pili-ios-camera-recorder/stargazers "收藏数")&nbsp;&nbsp;[🖖`38`](https://github.com/yuyedaidao/pili-ios-camera-recorder/network/members "分叉数")</span>

Pili iOS camera streaming framework via RTMP



---

### 2. [YQSlideMenuControllerDemo](https://github.com/yuyedaidao/YQSlideMenuControllerDemo) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/yuyedaidao/YQSlideMenuControllerDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`51`](https://github.com/yuyedaidao/YQSlideMenuControllerDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`14`](https://github.com/yuyedaidao/YQSlideMenuControllerDemo/network/members "分叉数")</span>

仿QQ左边菜单侧滑栏,SlideMenu



---

### 3. [RatingBar](https://github.com/yuyedaidao/RatingBar) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/yuyedaidao/RatingBar/watchers "关注数")&nbsp;&nbsp;[⭐️`41`](https://github.com/yuyedaidao/RatingBar/stargazers "收藏数")&nbsp;&nbsp;[🖖`15`](https://github.com/yuyedaidao/RatingBar/network/members "分叉数")</span>





---

### 4. [YQPrensetViewController](https://github.com/yuyedaidao/YQPrensetViewController) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/yuyedaidao/YQPrensetViewController/watchers "关注数")&nbsp;&nbsp;[⭐️`32`](https://github.com/yuyedaidao/YQPrensetViewController/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/yuyedaidao/YQPrensetViewController/network/members "分叉数")</span>





---

### 5. [AmazingButton](https://github.com/yuyedaidao/AmazingButton) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/yuyedaidao/AmazingButton/watchers "关注数")&nbsp;&nbsp;[⭐️`21`](https://github.com/yuyedaidao/AmazingButton/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/yuyedaidao/AmazingButton/network/members "分叉数")</span>





---

### 6. [YQSweepCardView](https://github.com/yuyedaidao/YQSweepCardView) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yuyedaidao/YQSweepCardView/watchers "关注数")&nbsp;&nbsp;[⭐️`15`](https://github.com/yuyedaidao/YQSweepCardView/stargazers "收藏数")&nbsp;&nbsp;[🖖`8`](https://github.com/yuyedaidao/YQSweepCardView/network/members "分叉数")</span>

仿淘宝‘猜你喜欢’展示卡片



---

### 7. [LeafScrollView](https://github.com/yuyedaidao/LeafScrollView) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yuyedaidao/LeafScrollView/watchers "关注数")&nbsp;&nbsp;[⭐️`15`](https://github.com/yuyedaidao/LeafScrollView/stargazers "收藏数")&nbsp;&nbsp;[🖖`6`](https://github.com/yuyedaidao/LeafScrollView/network/members "分叉数")</span>





---

### 8. [LeafNotification](https://github.com/yuyedaidao/LeafNotification) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yuyedaidao/LeafNotification/watchers "关注数")&nbsp;&nbsp;[⭐️`11`](https://github.com/yuyedaidao/LeafNotification/stargazers "收藏数")&nbsp;&nbsp;[🖖`7`](https://github.com/yuyedaidao/LeafNotification/network/members "分叉数")</span>





---

### 9. [YQLabel](https://github.com/yuyedaidao/YQLabel) <kbd title="主要编程语言">Swift</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yuyedaidao/YQLabel/watchers "关注数")&nbsp;&nbsp;[⭐️`7`](https://github.com/yuyedaidao/YQLabel/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/yuyedaidao/YQLabel/network/members "分叉数")</span>

Swift富文本Label,可点击



---

### 10. [CommentTextFieldDemo](https://github.com/yuyedaidao/CommentTextFieldDemo) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/yuyedaidao/CommentTextFieldDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`6`](https://github.com/yuyedaidao/CommentTextFieldDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/yuyedaidao/CommentTextFieldDemo/network/members "分叉数")</span>

超级简单用来快速评论或回复

