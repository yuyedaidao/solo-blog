title: ReactiveCocoa解读-订阅信号
date: '2018-11-09 22:17:15'
updated: '2018-11-09 22:17:15'
tags: [RAC, ReactiveCocoa, iOS]
permalink: /articles/2018/11/09/1573699414216.html
---
信号(Signal)和订阅者(Subscriber)是在[ReactiveCocoa](https://github.com/ReactiveCocoa/ReactiveCocoa)( 下文简称RAC)的相关资料中提到最多的概念了，但因为是从英文语境中直接翻译过来的，让国内大部分开发者对订阅信号一时难以理解，即使掌握了RAC的用法对此还是模棱两可。今天，我们尝试从RAC的源码去解读，看看订阅信号到底是个啥子过程。

先上一段RAC最简单的使用方法。

     RACSignal *signal = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        [subscriber sendNext:@"钢铁锅"];
        [subscriber sendNext:@"含眼泪喊修瓢锅"];
        [subscriber sendNext:@"坏缺烂角的换新锅瓢乱放"];
        [subscriber sendNext:@"哎...哎,哎,谁的鞋,不要乱扔..."];
        return [RACDisposable disposableWithBlock:^{
            NSLog(@"曲终人散，抹点药酒");
        }];
    }];
    [signal subscribeNext:^(id x) {
        NSLog(@"我听到:%@",x);
    }];

![这是什么锅](http://upload-images.jianshu.io/upload_images/69809-a6c41863589c6ff0.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

> 信号是信息的载体

对应上边的代码，我们创建了一个信号 `signal`，他承载着 `钢铁锅` `含眼泪喊修瓢锅` `坏缺烂角的换新锅瓢乱放` `哎...哎,哎,谁的鞋,不要乱扔...`这些信息。

    + (RACSignal *)createSignal:(RACDisposable * (^)(id<RACSubscriber> subscriber))didSubscribe {
        RACDynamicSignal *signal = [[self alloc] init];
        signal->_didSubscribe = [didSubscribe copy];
        return [signal setNameWithFormat:@"+createSignal:"];
    }
创建信号很简单，其实就是创建了一个实例对象，并把将来有可能进行的一系列操作`didSubscribe`这个block记录下来，等发生了订阅行为时就会执行这些操作。
有人会问RACDisposable是什么东西，其实从字面就可以理解，销毁，它封装了当订阅行为消失时一些应该做的操作，当然像一开始的代码这种只是打印消息的操作其实是没必要的，所以这里可以返回nil。那什么时候订阅行为消失呢，当订阅者调用了sendError:或者sendCompleted方法时表示订阅行为就消失了，相应的dispose就会执行了，做一些清理操作。如下面的代码：


    RACSignal *signal = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        [subscriber sendNext:@"钢铁锅"];
        [subscriber sendNext:@"含眼泪喊修瓢锅"];
        [subscriber sendError:[NSError errorWithDomain:@"singing" code:748 userInfo:@{@"reason":@"麦克被歌迷拔掉了"}]];
        [subscriber sendNext:@"坏缺烂角的换新锅瓢乱放"];
        [subscriber sendNext:@"哎...哎,哎,谁的鞋,不要乱扔..."];
        [subscriber sendError:NULL];
    //        [subscriber sendCompleted];
        return [RACDisposable disposableWithBlock:^{
            NSLog(@"曲终人散，抹点药酒");
        }];
    }];
![我错了](http://upload-images.jianshu.io/upload_images/69809-2a25a6514c7a7229.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
当然如果这两个方法如果你都不调用，那么当订阅者超出了自己的生命周期调用其dealloc方法时这个dispose也会执行。所以RACDisposable在RAC里使用非常广泛，比如在NSNotificationCenter的RAC扩展中用于取消观察者，在UITextField和UITextView的扩展里取消代理等等。

说了半天大家可能会问，订阅者在哪里？别急，看下面:

    [signal subscribeNext:^(id x) {
        NSLog(@"我听到:%@",x);
    }];
当这句代码执行时就发生了订阅行为。其内部实现是这样：

    - (RACDisposable *)subscribeNext:(void (^)(id x))nextBlock {
         NSCParameterAssert(nextBlock != NULL);
         //看到了吗？我在这里，我就是订阅者。我把 nextBlock保存了下来。
         RACSubscriber *o = [RACSubscriber subscriberWithNext:nextBlock   error:NULL completed:NULL];
         return [self subscribe:o];
    }

    - (RACDisposable *)subscribe:(id<RACSubscriber>)subscriber {
         NSCParameterAssert(subscriber != nil);
         RACCompoundDisposable *disposable = [RACCompoundDisposable compoundDisposable];
         //加工了一下，变成了RACPassthroughSubscriber,关于它的作用我们在以后的文章总具体场景下再讲述，现在你只需记住一个更具体的RACSubscriber子类就行了。
         subscriber = [[RACPassthroughSubscriber alloc] initWithSubscriber:subscriber signal:self disposable:disposable];
         //还记得信号在一开始创建时就存下来的那个block吗，就是这个didSubscribe
         if (self.didSubscribe != NULL) {
             RACDisposable *schedulingDisposable =  [RACScheduler.subscriptionScheduler schedule:^{
                 //在这里支行了信号一开始创建的block，并获得了它返回的RACDisposable
                 RACDisposable *innerDisposable = self.didSubscribe(subscriber);
                 [disposable addDisposable:innerDisposable];
             }];
            [disposable addDisposable:schedulingDisposable];
        }
        return disposable;
    }
看到这里你可能有产生了很多疑问，且听我慢慢道来。首先你在头脑里先产生这个场景：生成了一个subscriber(代号007)，它保存了一个nextBlock：`^(id x) { NSLog(@"我听到:%@",x);}`,然后当前这个信号开始执行didSubscribe这个block:

    ^RACDisposable *(id<RACSubscriber> subscriber) { 
      [subscriber sendNext:@"钢铁锅"];
      [subscriber sendNext:@"含眼泪喊修瓢锅"];
      [subscriber sendNext:@"坏缺烂角的换新锅瓢乱放"]; 
      [subscriber sendNext:@"哎...哎,哎,谁的鞋,不要乱扔..."];
      [subscriber sendCompleted]; 
      return [RACDisposable disposableWithBlock:^{
           NSLog(@"曲终人散，抹点药酒"); 
      }];
    }
注意，007被当作参数传了进去，也就是调用sendNext:这个方法的都是007，还记得007保存的那个nextBlock吗，此时在sendNext:内部就是执行了这个nextBlock，传进去了`钢铁锅` `含眼泪喊修瓢锅` `坏缺烂角的换新锅瓢乱放` `哎...哎,哎,谁的鞋,不要乱扔...`这些信息。这样作为开发者的你就收到了订阅者发给你的有用信息，你就“听”到了一首美妙的歌曲。

整个一个订阅流程就这样结束了，当然你会发现在你的代码中subscriber始终都没暴露出来，这也是造成你疑惑的原因，那么我问你，你需要的是subscriber呢，还是subscriber发给你的信息呢？因为我们需要的只是信息，所以完全没必要让我们知道subscriber的存在。所谓的订阅者也就是subscriber其实就是起了一个中间人的作用，获取信号(或者叫信号源更好理解)里的信息，然后发送到需要的地方。


![keynote图形好少啊](http://upload-images.jianshu.io/upload_images/69809-058f5b522000e7ce.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

RACCompoundDisposable(RACDisposable的子类)应该是大家的另一个疑问，它有一个方法`addDisposable:`可以添加另一个RACDisposable，它的最终形态是一个树形结构，第一个RACCompoundDisposable存了若干个RACDisposable或者RACCompoundDisposable，相应的RACCompoundDisposable又存了若干个RACDisposable或者RACCompoundDisposable...每个元素里边存的都是一些block形式存在的清理操作，这样当执行树的根节点的dispose时，整棵树就会按顺序执行清理操作了。

那么，讲到这里就先告一段落了，等有时间我会把RAC更复杂场景下的使用流程介绍给大家。

希望能对您有一点帮助。