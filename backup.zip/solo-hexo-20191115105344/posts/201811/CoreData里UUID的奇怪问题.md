title: CoreData里UUID的奇怪问题
date: '2018-11-09 22:25:54'
updated: '2018-11-09 22:25:54'
tags: [CoreData, iOS]
permalink: /articles/2018/11/09/1573699417391.html
---
## 0x1
今天我在开发AppleWatch应用时发现了一个关于CoreData的极其古怪的问题,特此记录下来

## 0x2
因为CoreData是支持UUID类型的属性的,所以我在设计某个Model时就用了UUID的属性,但是因为不是连续开发导致我后来把这个属性的类型忘了,以为是String.

于是我在手机端的代码里写了类似这样的代码
```
let uuid: String = "7BD09D86-8941-4E50-9A42-7240E970FEE7"
let predicate = NSPredicate(format: "uuid = %@", argumentArray: [uuid])
//省略CoreData根据predicate获取数据的代码
```
*注意Model里uuid的属性类型是UUID,我在这里直接用的是String*
然后,我...很成功的获取到了预期的数据.
当然,我当时并没有意识到类型不匹配.

于是乎,我把相同的代码放到了
```
//MARK: -WCSession的代理方法 Watch向iPhone发送的消息在这里接收
 func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) 
```
然后,我怎么也获取不到数据了,一模一样的代码,我曾一度变成了有神论者,简直诡异至极....
获取数据的方法我放在什么线程里都不行,这个代理函数的执行环境我不知道跟主应用的程序执行环境有什么不同

## 0x3
结果到目前为止大家肯定已经知道了,就是把查询时的String类型的uuid修改成UUID类型
## 0x4
原因未知