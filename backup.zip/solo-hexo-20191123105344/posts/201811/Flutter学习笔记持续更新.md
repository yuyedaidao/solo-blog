title: Flutter学习笔记(持续更新)
date: '2018-11-20 02:11:43'
updated: '2018-11-20 02:11:43'
tags: [Flutter]
permalink: /articles/2018/11/20/1573699411667.html
---
1. InkWell (中文俗称 水波纹、油墨等) 如果在调试时发现没有效果，首先确认有没有给onTap赋值，而且必须**不能**是匿名空函数`()=>{}`,必须有实现，其次再包裹Material调试