title: Swift小知识
date: '2019-11-14 10:43:32'
updated: '2019-11-14 10:43:32'
tags: [Note]
permalink: /articles/2019/11/14/1573699412508.html
---

title: Swift小知识
date: 2019-02-27 10:42:55
tags: 
	- Swift
categories: 
	- iOS

---

1. `class`修饰的func可以被重写，`static`不可以
2. protocol中要求实现的方法必须保证访问控制修饰符也要正确，尤其是对于可选实现的方法，如果修饰符不对就会被当做没有实现
3. 如果调用`Error`的`localizedDescription`方法跟你重写的内容不一样，那你八成是没有让你的`Error`实现`LocalizedError`协议