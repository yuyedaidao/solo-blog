title: SSH免密登录
date: '2018-11-20 02:11:43'
updated: '2018-11-20 02:11:43'
tags: [Server, ssh]
permalink: /articles/2018/11/20/1573699416036.html
---
## 说明
 - **Client** -> 你当前使用的设备，例如我正在敲代码的MacBookPro
 - **Server** -> 你要免密登录的服务器

## 在Client上生成秘钥

1. 打开终端输入命令`cd ~/.ssh`
2. 继续输入`ssh-keygen -t rsa`,然后一路回车
3. 执行命令`cat id_rsa.pub>>authorized_keys`
4. 修改文件*authorized_keys*的权限,执行命令`chmod 600 authorized_keys`
5. 修改目录*~/.ssh*的权限，执行命令`chmod 700 ~/.ssh`
6. 复制公钥文本，输入`cat authorized_keys`,然后复制出现的文本。形如以下

```
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCsopScfdy/3dfxLXErZVX5ZHn83mA8a/YZyo29FbEoOf3ayPSbK1jUZRbC1bEV86g3PcdwNqZOakaaAQpqT74aKx3+1AfsrxLD1mar6NnUd6Rlup7FrTe7lD4MNj5brK+PJtzFpV2gzszCeS34ZvfnlNvaHRO+8i8puUA9CMu9e6A8I7msb32nAHr+vDjw9HkEtBCadigbbxdiykgKEQJgbKOJy+Ksswc48lsX XX@bogon
```

## 在Server上添加Client上的公钥
*注意* 下面的操作转移到你要登录的服务器上了

1. `cd ~/.ssh`到你当前用户的.ssh目录下
2. `vi authorized_keys`，然后把你刚才在Client上复制的文本粘贴进去
3. 按下`Esc`,输入`wq!`保存
4. `service sshd restart`,重启sshd

## 基本操作完成，可以登录了
如果还不行可能需要修改权限或者修改文件/etc/ssh/sshd_config